package com.lang4you.wadetector;

import android.accessibilityservice.AccessibilityService;import android.view.accessibility.AccessibilityEvent;import android.view.accessibility.AccessibilityNodeInfo;import android.os.*;import java.util.*;import java.util.regex.*;import java.net.*;import java.io.*;

public class WhatsAppAccessibilityService extends AccessibilityService {
 public static boolean enabled=false; private long last=0; private String lastSig="";
 @Override public void onServiceConnected(){enabled=true;}
 @Override public void onInterrupt(){enabled=false;}
 @Override public void onAccessibilityEvent(AccessibilityEvent e){if(e.getPackageName()==null||!e.getPackageName().toString().toLowerCase().contains("whatsapp"))return;if(System.currentTimeMillis()-last<700)return;last=System.currentTimeMillis(); AccessibilityNodeInfo root=getRootInActiveWindow(); if(root==null)return; ArrayList<String> a=new ArrayList<>(); collect(root,a);String raw=String.join(" ",a);String low=raw.toLowerCase(Locale.ROOT);if(!low.contains("receive sms")&&!low.contains("missed call")&&!low.contains("voice call"))return;
 boolean sms=low.contains("receive sms")&&!low.matches(".*receive sms.*try again in.*");boolean missed=low.contains("missed call");boolean voice=low.contains("voice call");String cooldown=null;Matcher m=Pattern.compile("try again in\\s+([^\\n]+?)(?:missed call|voice call|$)",Pattern.CASE_INSENSITIVE).matcher(raw);if(m.find())cooldown=m.group(1).trim();String number="Unknown";Matcher n=Pattern.compile("(?:\\+\\d[\\d ]{6,})").matcher(raw);if(n.find())number=n.group().trim();String sig=number+"|"+sms+"|"+missed+"|"+voice+"|"+cooldown;if(sig.equals(lastSig))return;lastSig=sig;
 getSharedPreferences("detector",0).edit().putString("last",sig).apply();
 sendStatus(number,sms,missed,voice,cooldown,raw);
 }
void sendStatus(String number, boolean sms, boolean missed, boolean voice, String cooldown, String raw){
  String server=getSharedPreferences("detector",0).getString("server","http://127.0.0.1:8787");
  String key=getSharedPreferences("detector",0).getString("key","WA-DETECTOR-2026");
  new Thread(() -> { try {
    URL u=new URL(server+"/status"); HttpURLConnection c=(HttpURLConnection)u.openConnection(); c.setRequestMethod("POST"); c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("x-api-key",key); c.setDoOutput(true);
    String body="{\"number\":\""+esc(number)+"\",\"sms\":"+sms+",\"missedCall\":"+missed+",\"voiceCall\":"+voice+",\"cooldown\":"+(cooldown==null?"null":"\""+esc(cooldown)+"\"")+",\"raw\":\""+esc(raw)+"\"}";
    try(OutputStream o=c.getOutputStream()){o.write(body.getBytes("UTF-8"));} c.getResponseCode(); c.disconnect();
  } catch(Exception ignored) {} }).start();
 }
 static String esc(String s){return s==null?"":s.replace("\\","\\\\").replace("\"","\\\"").replace("\n"," ");}
 void collect(AccessibilityNodeInfo n,ArrayList<String> out){if(n==null)return;CharSequence t=n.getText();if(t!=null&&!t.toString().trim().isEmpty())out.add(t.toString().trim());for(int i=0;i<n.getChildCount();i++)collect(n.getChild(i),out);}
}
