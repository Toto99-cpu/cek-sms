package com.lang4you.wadetector;

import android.app.*;import android.os.*;import android.provider.Settings;import android.content.*;import android.net.Uri;import android.view.*;import android.widget.*;import java.io.*;import java.net.*;import java.util.*;

public class MainActivity extends Activity {
 EditText server,key; TextView status,result;
 @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main); server=findViewById(R.id.server);key=findViewById(R.id.apiKey);status=findViewById(R.id.status);result=findViewById(R.id.result);server.setText(getPreferences(0).getString("server","http://127.0.0.1:8787"));key.setText(getPreferences(0).getString("key","WA-DETECTOR-2026"));
 findViewById(R.id.access).setOnClickListener(v->{startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));});
 findViewById(R.id.test).setOnClickListener(v->{save();send("+TEST",true,true,true,null,"Manual test");}); update(); }
 void save(){getPreferences(0).edit().putString("server",server.getText().toString().trim()).putString("key",key.getText().toString().trim()).apply(); getSharedPreferences("detector",0).edit().putString("server",server.getText().toString().trim()).putString("key",key.getText().toString().trim()).apply();}
 void update(){status.setText(WhatsAppAccessibilityService.enabled?"Accessibility: ON":"Accessibility: OFF");}
 @Override protected void onResume(){super.onResume();update();}
 public void send(String number,boolean sms,boolean missed,boolean voice,String cooldown,String raw){save(); new Thread(()->{try{URL u=new URL(server.getText().toString().trim()+"/status");HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setRequestMethod("POST");c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("x-api-key",key.getText().toString().trim());c.setDoOutput(true);String body="{\"number\":\""+esc(number)+"\",\"sms\":"+sms+",\"missedCall\":"+missed+",\"voiceCall\":"+voice+",\"cooldown\":"+(cooldown==null?"null":"\""+esc(cooldown)+"\"")+",\"raw\":\""+esc(raw)+"\"}";try(OutputStream o=c.getOutputStream()){o.write(body.getBytes("UTF-8"));}int code=c.getResponseCode();runOnUiThread(()->result.setText("Server response: HTTP "+code));c.disconnect();}catch(Exception e){runOnUiThread(()->result.setText("Error: "+e.getMessage()));}}).start();}
 static String esc(String s){return s==null?"":s.replace("\\","\\\\").replace("\"","\\\"").replace("\n"," ");}
}
