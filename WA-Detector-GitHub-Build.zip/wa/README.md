# WA Detector - LANG4YOU

Native Android Accessibility Service detector for the WhatsApp verification screen.

## Build tanpa Android Studio

1. Upload this project to a GitHub repository.
2. Open **Actions**.
3. Select **Build WA Detector APK**.
4. Press **Run workflow** (or push to `main`).
5. Open the completed workflow run.
6. Download artifact **WA-Detector-debug-apk**.

The workflow builds a real Android debug APK using Android SDK/Build Tools supplied by GitHub Actions.

The app observes visible WhatsApp UI text only. It does not read or retrieve SMS/OTP codes.
